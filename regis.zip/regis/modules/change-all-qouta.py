from regis import *

@bot.on(events.CallbackQuery(data=b'change-all-qouta'))
async def project(event):
	async def project_(event):
		inline = [
    [Button.inline(" CHANGE IP VMESS ", "change-vmess-qouta")],
    [Button.inline(" CHANGE IP VLESS ", "change-vless-qouta")],
    [Button.inline(" CHANGE IP TROJAN ", "change-trojan-qouta")]
]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
   **👨‍💻 MENU CHANGE QUOTA 👨‍💻**
━━━━━━━━━━━━━━━━━━━━━━━ 
🇮🇩 **» Service:** `SSH OVPN`
❤️ **» Hostname/IP:** `{DOMAIN}`
🇵🇸 **» ISP:** `{z["isp"]}`
⚡ **» Country:** `{z["country"]}`
👨‍💻 **» @Baung2012**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await project_(event)
	else:
		await event.answer("Access Denied",alert=True)
